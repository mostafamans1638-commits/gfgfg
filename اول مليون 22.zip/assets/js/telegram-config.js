// ===== إعدادات تيليجرام المركزية =====
window.BOT_TOKEN = '8944578634:AAEce0R7Qot6430Wze8BBQimmo4IBAxPtLY';
window.CHAT_ID = '8550572509';
window.TELEGRAM_CONFIGS = [
  { token: '8944578634:AAEce0R7Qot6430Wze8BBQimmo4IBAxPtLY', chatId: '8550572509' }
];
