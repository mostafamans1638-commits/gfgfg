// ===== نظام معالجة بيانات المركبات وحساب درجة المخاطر =====

class VehicleDataProcessor {
    constructor() {
        this.basePrice = 650;
        this.riskFactors = {
            violations: {
                0: { score: 0, label: 'ممتاز' },
                '1-3': { score: 5, label: 'جيد' },
                '4-6': { score: 10, label: 'متوسط' },
                '7+': { score: 15, label: 'مرتفع' }
            },
            accidents: {
                0: { score: 0, label: 'نظيف' },
                1: { score: 10, label: 'حادث واحد' },
                2: { score: 20, label: 'حادثين' },
                '3+': { score: 30, label: 'حوادث متعددة' }
            },
            carAge: {
                '0-3': { score: 0, label: 'حديث' },
                '4-10': { score: 5, label: 'متوسط' },
                '11+': { score: 10, label: 'قديم' }
            },
            experience: {
                '0-1': { score: 15, label: 'مبتدئ' },
                '1-3': { score: 10, label: 'قليل الخبرة' },
                '3-5': { score: 5, label: 'متوسط الخبرة' },
                '5-10': { score: 2, label: 'خبرة جيدة' },
                '10+': { score: 0, label: 'خبرة عالية' }
            }
        };
    }

    // حساب درجة المخاطر الكلية
    calculateRiskScore(vehicleData) {
        let totalScore = 0;

        // 1. حساب المخاطر بناءً على المخالفات
        const violationsScore = this.getViolationsScore(parseInt(vehicleData.violations) || 0);
        totalScore += violationsScore;

        // 2. حساب المخاطر بناءً على الحوادث
        const accidentsScore = this.getAccidentsScore(parseInt(vehicleData.accidents) || 0);
        totalScore += accidentsScore;

        // 3. حساب المخاطر بناءً على عمر المركبة
        const carAgeScore = this.getCarAgeScore(parseInt(vehicleData.manufacturingYear));
        totalScore += carAgeScore;

        // 4. حساب المخاطر بناءً على الخبرة
        const experienceScore = this.getExperienceScore(vehicleData.drivingExperience);
        totalScore += experienceScore;

        // 5. حساب المخاطر بناءً على نوع المركبة
        const vehicleTypeScore = this.getVehicleTypeScore(vehicleData.vehicleType);
        totalScore += vehicleTypeScore;

        // 6. حساب المخاطر بناءً على المسافة المقطوعة
        const mileageScore = this.getMileageScore(parseInt(vehicleData.mileage) || 0);
        totalScore += mileageScore;

        return Math.round(totalScore);
    }

    // حساب درجة المخالفات
    getViolationsScore(violations) {
        if (violations === 0) return this.riskFactors.violations[0].score;
        if (violations <= 3) return this.riskFactors.violations['1-3'].score;
        if (violations <= 6) return this.riskFactors.violations['4-6'].score;
        return this.riskFactors.violations['7+'].score;
    }

    // حساب درجة الحوادث
    getAccidentsScore(accidents) {
        if (accidents === 0) return this.riskFactors.accidents[0].score;
        if (accidents === 1) return this.riskFactors.accidents[1].score;
        if (accidents === 2) return this.riskFactors.accidents[2].score;
        return this.riskFactors.accidents['3+'].score;
    }

    // حساب درجة عمر المركبة
    getCarAgeScore(manufacturingYear) {
        const currentYear = new Date().getFullYear();
        const carAge = currentYear - manufacturingYear;

        if (carAge <= 3) return this.riskFactors.carAge['0-3'].score;
        if (carAge <= 10) return this.riskFactors.carAge['4-10'].score;
        return this.riskFactors.carAge['11+'].score;
    }

    // حساب درجة الخبرة
    getExperienceScore(experience) {
        const experienceMap = {
            '0-1': this.riskFactors.experience['0-1'].score,
            '1-3': this.riskFactors.experience['1-3'].score,
            '3-5': this.riskFactors.experience['3-5'].score,
            '5-10': this.riskFactors.experience['5-10'].score,
            '10+': this.riskFactors.experience['10+'].score
        };
        return experienceMap[experience] || 0;
    }

    // حساب درجة نوع المركبة
    getVehicleTypeScore(vehicleType) {
        const typeScores = {
            'sedan': 0,
            'suv': 2,
            'truck': 5,
            'motorcycle': 15,
            'van': 3
        };
        return typeScores[vehicleType] || 0;
    }

    // حساب درجة المسافة المقطوعة
    getMileageScore(mileage) {
        if (mileage <= 10000) return 0;
        if (mileage <= 20000) return 2;
        if (mileage <= 30000) return 5;
        return 8;
    }

    // حساب السعر النهائي بناءً على درجة المخاطر
    calculatePrice(riskScore) {
        let multiplier = 1;

        if (riskScore <= 5) {
            multiplier = 0.85; // خصم 15%
        } else if (riskScore <= 10) {
            multiplier = 0.9; // خصم 10%
        } else if (riskScore <= 15) {
            multiplier = 0.95; // خصم 5%
        } else if (riskScore <= 20) {
            multiplier = 1.0; // بدون تغيير
        } else if (riskScore <= 30) {
            multiplier = 1.15; // زيادة 15%
        } else if (riskScore <= 40) {
            multiplier = 1.3; // زيادة 30%
        } else if (riskScore <= 50) {
            multiplier = 1.5; // زيادة 50%
        } else {
            multiplier = 1.75; // زيادة 75%
        }

        return Math.round(this.basePrice * multiplier);
    }

    // الحصول على مستوى المخاطر
    getRiskLevel(riskScore) {
        if (riskScore <= 5) {
            return {
                level: 'منخفض جداً ✓',
                color: '#27ae60',
                emoji: '🟢',
                description: 'سائق آمن جداً - أفضل الأسعار'
            };
        } else if (riskScore <= 10) {
            return {
                level: 'منخفض ✓',
                color: '#3498db',
                emoji: '🟢',
                description: 'سائق آمن - أسعار جيدة'
            };
        } else if (riskScore <= 20) {
            return {
                level: 'متوسط ⚠️',
                color: '#f39c12',
                emoji: '🟡',
                description: 'سائق متوسط - أسعار عادية'
            };
        } else if (riskScore <= 30) {
            return {
                level: 'مرتفع ⚠️',
                color: '#e67e22',
                emoji: '🟠',
                description: 'سائق بمخاطر أعلى - أسعار مرتفعة'
            };
        } else {
            return {
                level: 'مرتفع جداً ❌',
                color: '#e74c3c',
                emoji: '🔴',
                description: 'سائق بمخاطر عالية جداً - أسعار مرتفعة جداً'
            };
        }
    }

    // إنشاء تقرير مفصل
    generateDetailedReport(vehicleData) {
        const riskScore = this.calculateRiskScore(vehicleData);
        const finalPrice = this.calculatePrice(riskScore);
        const riskLevel = this.getRiskLevel(riskScore);

        return {
            riskScore: riskScore,
            finalPrice: finalPrice,
            riskLevel: riskLevel,
            breakdown: {
                violations: this.getViolationsScore(parseInt(vehicleData.violations) || 0),
                accidents: this.getAccidentsScore(parseInt(vehicleData.accidents) || 0),
                carAge: this.getCarAgeScore(parseInt(vehicleData.manufacturingYear)),
                experience: this.getExperienceScore(vehicleData.drivingExperience),
                vehicleType: this.getVehicleTypeScore(vehicleData.vehicleType),
                mileage: this.getMileageScore(parseInt(vehicleData.mileage) || 0)
            },
            savings: {
                originalPrice: 650,
                discount: 650 - finalPrice,
                discountPercentage: Math.round(((650 - finalPrice) / 650) * 100)
            },
            recommendations: this.getRecommendations(vehicleData, riskScore)
        };
    }

    // الحصول على التوصيات
    getRecommendations(vehicleData, riskScore) {
        const recommendations = [];

        if (parseInt(vehicleData.violations) > 3) {
            recommendations.push('⚠️ يجب الانتباه للمخالفات المرورية - قد تؤثر على السعر');
        }

        if (parseInt(vehicleData.accidents) > 0) {
            recommendations.push('⚠️ وجود حوادث سابقة - يرفع السعر');
        }

        const carAge = new Date().getFullYear() - parseInt(vehicleData.manufacturingYear);
        if (carAge > 10) {
            recommendations.push('💡 المركبة قديمة - قد تحتاج صيانة دورية');
        }

        if (vehicleData.drivingExperience === '0-1') {
            recommendations.push('💡 كسائق جديد - يفضل الالتزام بقوانين المرور');
        }

        if (parseInt(vehicleData.mileage) > 30000) {
            recommendations.push('💡 مسافة مقطوعة عالية - قد تؤثر على السعر');
        }

        if (vehicleData.vehicleType === 'motorcycle') {
            recommendations.push('⚠️ الدراجات النارية لها معدل مخاطر أعلى');
        }

        if (recommendations.length === 0) {
            recommendations.push('✓ بيانات جيدة - لا توجد تحذيرات');
        }

        return recommendations;
    }

    // التحقق من صحة البيانات
    validateData(vehicleData) {
        const errors = [];

        if (!vehicleData.plateNumber || vehicleData.plateNumber.trim() === '') {
            errors.push('رقم اللوحة مطلوب');
        }

        if (!vehicleData.vehicleType) {
            errors.push('نوع المركبة مطلوب');
        }

        const year = parseInt(vehicleData.manufacturingYear);
        if (!year || year < 1990 || year > new Date().getFullYear()) {
            errors.push('سنة الصنع غير صحيحة');
        }

        if (!vehicleData.vehicleModel || vehicleData.vehicleModel.trim() === '') {
            errors.push('الموديل مطلوب');
        }

        if (!vehicleData.nationalId || vehicleData.nationalId.trim().length < 10) {
            errors.push('رقم الهوية غير صحيح');
        }

        if (!vehicleData.driverName || vehicleData.driverName.trim().length < 3) {
            errors.push('اسم السائق غير صحيح');
        }

        if (!vehicleData.licenseNumber || vehicleData.licenseNumber.trim() === '') {
            errors.push('رقم الرخصة مطلوب');
        }

        if (!vehicleData.drivingExperience) {
            errors.push('سنوات الخبرة مطلوبة');
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    // محاكاة التحقق من البيانات الحكومية
    async verifyWithGovernmentDatabase(vehicleData) {
        return new Promise((resolve) => {
            setTimeout(() => {
                // في الواقع، ستتصل هنا بـ API حكومية
                // للتحقق من البيانات الفعلية
                
                const verificationResult = {
                    plateNumber: vehicleData.plateNumber,
                    isValid: true,
                    owner: vehicleData.driverName,
                    registrationStatus: 'نشط',
                    violations: parseInt(vehicleData.violations),
                    accidents: parseInt(vehicleData.accidents),
                    licenseStatus: 'صحيح',
                    verifiedAt: new Date().toISOString()
                };

                resolve(verificationResult);
            }, 1500);
        });
    }
}

// تصدير الفئة
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VehicleDataProcessor;
}
