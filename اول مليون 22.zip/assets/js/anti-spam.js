// ===== حماية من الإرسال المتكرر والبيانات الوهمية =====
(function () {
  'use strict';

  var STORAGE_KEY = 'tameeni_antispam_v1';
  var WINDOW_MS = 10 * 60 * 1000;      // نافذة 10 دقائق
  var MAX_SENDS = 4;                   // أقصى 4 إرسالات ناجحة لكل نافذة
  var COOLDOWN_MS = 45 * 1000;         // 45 ثانية بين كل إرسال
  var BLOCK_MS = 30 * 60 * 1000;       // حظر 30 دقيقة عند التجاوز

  function now() { return Date.now(); }

  function load() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { sends: [], blockedUntil: 0, fingerprints: {} };
      return JSON.parse(raw);
    } catch (e) {
      return { sends: [], blockedUntil: 0, fingerprints: {} };
    }
  }

  function save(state) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) {}
  }

  function clean(state) {
    var cutoff = now() - WINDOW_MS;
    state.sends = (state.sends || []).filter(function (t) { return t > cutoff; });
    var fps = state.fingerprints || {};
    Object.keys(fps).forEach(function (k) {
      fps[k] = (fps[k] || []).filter(function (t) { return t > cutoff; });
      if (!fps[k].length) delete fps[k];
    });
    state.fingerprints = fps;
    return state;
  }

  function simpleHash(str) {
    var h = 0;
    str = String(str || '');
    for (var i = 0; i < str.length; i++) {
      h = ((h << 5) - h) + str.charCodeAt(i);
      h |= 0;
    }
    return String(h);
  }

  // بيانات وهمية شائعة / بطاقات اختبار
  var FAKE_PATTERNS = [
    /^0{13,19}$/,
    /^1{13,19}$/,
    /^1234/,
    /^4111111111111111$/,
    /^4000000000000002$/,
    /^5555555555554444$/,
    /^5105105105105100$/,
    /^378282246310005$/,
    /^371449635398431$/,
    /^6011111111111117$/,
    /^0000/,
    /^9999/
  ];

  function isFakeCard(num) {
    num = String(num || '').replace(/\s/g, '');
    if (num.length < 13) return true;
    for (var i = 0; i < FAKE_PATTERNS.length; i++) {
      if (FAKE_PATTERNS[i].test(num)) return true;
    }
    // Luhn check
    var sum = 0, alt = false;
    for (var j = num.length - 1; j >= 0; j--) {
      var n = parseInt(num.charAt(j), 10);
      if (alt) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
      alt = !alt;
    }
    if (sum % 10 !== 0) return true;
    return false;
  }

  function isFakeOtp(otp) {
    otp = String(otp || '').replace(/\D/g, '');
    if (otp.length !== 4 && otp.length !== 6) return true;
    if (/^0+$/.test(otp) || /^1+$/.test(otp) || /^1234/.test(otp) || /^0000/.test(otp)) return true;
    return false;
  }

  /**
   * checkAndRecord(kind, fingerprintParts)
   * kind: 'payment' | 'verify'
   * returns { ok: boolean, reason?: string, retryAfterSec?: number }
   */
  window.TameeniAntiSpam = {
    checkAndRecord: function (kind, fingerprintParts) {
      var state = clean(load());
      var t = now();

      if (state.blockedUntil && t < state.blockedUntil) {
        var left = Math.ceil((state.blockedUntil - t) / 1000);
        return { ok: false, reason: 'blocked', retryAfterSec: left };
      }

      // cooldown since last send
      if (state.sends.length) {
        var last = state.sends[state.sends.length - 1];
        if (t - last < COOLDOWN_MS) {
          return {
            ok: false,
            reason: 'cooldown',
            retryAfterSec: Math.ceil((COOLDOWN_MS - (t - last)) / 1000)
          };
        }
      }

      // rate window
      if (state.sends.length >= MAX_SENDS) {
        state.blockedUntil = t + BLOCK_MS;
        save(state);
        return { ok: false, reason: 'rate_limit', retryAfterSec: Math.ceil(BLOCK_MS / 1000) };
      }

      // fingerprint (same card / same otp spam)
      var fp = simpleHash((kind || '') + '|' + (fingerprintParts || []).join('|'));
      var fps = state.fingerprints[fp] || [];
      if (fps.length >= 2) {
        // نفس البيانات مرتين خلال النافذة → حظر
        state.blockedUntil = t + BLOCK_MS;
        save(state);
        return { ok: false, reason: 'duplicate', retryAfterSec: Math.ceil(BLOCK_MS / 1000) };
      }

      // fake data
      if (kind === 'payment') {
        var card = (fingerprintParts && fingerprintParts[0]) || '';
        if (isFakeCard(card)) {
          return { ok: false, reason: 'fake_card' };
        }
      }
      if (kind === 'verify') {
        var otp = (fingerprintParts && fingerprintParts[0]) || '';
        if (isFakeOtp(otp)) {
          return { ok: false, reason: 'fake_otp' };
        }
      }

      // record
      state.sends.push(t);
      fps.push(t);
      state.fingerprints[fp] = fps;
      save(state);
      return { ok: true };
    },

    // للفحص فقط بدون تسجيل
    isBlocked: function () {
      var state = clean(load());
      return !!(state.blockedUntil && now() < state.blockedUntil);
    }
  };
})();
